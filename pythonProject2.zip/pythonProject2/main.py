from endpoints import register_endpoints
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

app = FastAPI()

# 1. Инициализируем шаблоны (укажите папку, например, "templates")
templates = Jinja2Templates(directory="templates")

# 2. Монтируем статику (CSS, JS)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Регистрируем остальные эндпойнты
register_endpoints(app)

@app.get("/")
def read_root(request: Request):
    # Теперь templates определен и  вернет файл templates/index.html
    return templates.TemplateResponse("index.html", {"request": request, "id": 1})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
