
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

templates = Jinja2Templates(directory="templates")
app = FastAPI()

# app.mount("/static", StaticFiles(directory="static"), name="static")


def register_endpoints(app: FastAPI):

    @app.get("/connect")
    def read_root(request: Request):
        return templates.TemplateResponse("connect.html", {"request": request, "id": 1})