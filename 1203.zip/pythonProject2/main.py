from fastapi import FastAPI, WebSocket, Request, WebSocketDisconnect
from fastapi.templating import Jinja2Templates
from endpoints import register_endpoints
import uvicorn

app = FastAPI()
templates = Jinja2Templates(directory="templates")
register_endpoints(app)

# Хранилище активных соединений
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        print(f"Новое подключение. Всего: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            print(f"Соединение закрыто. Осталось: {len(self.active_connections)}")

    async def broadcast(self, message: str):
        # Рассылаем всем. Если кто-то отвалился — удаляем его из списка
        for connection in self.active_connections[:]:  # Копия списка для безопасного удаления
            try:
                await connection.send_text(message)
            except Exception:
                self.disconnect(connection)


manager = ConnectionManager()


@app.get("/")
async def get(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Ждем данные от любого клиента (браузера или ESP)
            data = await websocket.receive_text()
            print(f"Лог сообщения: {data}")

            # Рассылаем полученное сообщение всем остальным
            await manager.broadcast(data)

    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"Ошибка: {e}")
        manager.disconnect(websocket)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
