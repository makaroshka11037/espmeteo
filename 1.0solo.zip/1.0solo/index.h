 #pragma once

const char webpage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Метеостанция</title>
    <style type="text/css">
        .button {
            background-color: #3498db;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        body {
            background-image: url(https://img.freepik.com/premium-photo/low-angle-view-building-against-cloudy-sky_1048944-26912393.jpg);
            background-repeat: no-repeat; /* Не повторять картинку */
            background-position-y: -250px; /* Центрировать картинку */
            background-size: cover; /* Растянуть на весь экран */
            background-color: #f0f0f0; 
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #34495e;
        }

	.blok1 {
  		/* Используем rgba (красный, зеленый, синий, прозрачность от 0 до 1) */
  		background-color: rgba(255, 255, 255, 0.2); /* Белый фон на 50% прозрачный */
  		
  		border: 1px solid #ccc;
  		padding: 20px;
  		width: 300px;
  		border-radius: 10px; 
		
  
  		/* Эффект матового стекла (по желанию) */
  		backdrop-filter: blur(10px);
	}
	.temp {
		font-size: 25px;
		// margin-left: -220px;
}
	.kamoji {
}
	</style>
</head>
<body>
    <center>
        <div>
            <h1>METEOSTATION PANEL</h1>
	    <div class="blok1">
	    <h3>♥Дом</h3>
	    <span class="temp" id="custom_data"></span>
	    
	    </div>


            <button class="button" id="knopka" onclick="requestCustomData()">Получить данные</button>
        </div>
        <br>
        <div>
            <h2>
                <span id="custom_data">Привет!</span>
            </h2>
        </div>
	

	<div id="result"></div>

        <script>
    const button = document.getElementById('knopka');

    function requestCustomData() {
        button.innerText = 'В процессе...';

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    document.getElementById("custom_data").innerHTML = this.responseText;
		    processsmile();
                } else {
                    document.getElementById("custom_data").innerHTML = "Ошибка";
                }
                button.innerText = 'Получить данные'; // ← ТОЛЬКО ТУТ
            }
        };

        xhttp.open("GET", "/gettemp", true);
        xhttp.send();
    }
</script>


<script>
function processsmile() {
    // Получаем элемент с данными
    const dataBlock = document.getElementById('custom_data');
    const resultDiv = document.getElementById('result');
    
    // Получаем текст и разбиваем на строки
    const fullText = dataBlock.innerHTML; // или textContent если не нужно сохранять HTML
    const lines = fullText.split('<br>');
    
    // Берем первую строку (где температура)
    const tempLine = lines[0].trim();
    
    // Извлекаем числовое значение температуры
    // Удаляем все нецифровые символы кроме точки и минуса
    const tempMatch = tempLine.match(/(-?\d+\.?\d*)/);
    
    if (tempMatch) {
        const temperature = parseFloat(tempMatch[1]);
        
        // Выводим в консоль для отладки
        console.log('Найдена температура:', temperature + '°C');
        
        // Определяем, какую строку выводить
        let outputHTML = '';
        
        if (temperature > 21.9) {
            outputHTML = '<img src="https://raw.githubusercontent.com/makaroshka11037/espmeteo/refs/heads/main/5262562830095252729.webp" alt="Если картинка не грузится - обратитесь к разработчику" width="256px" height="256px"></img>';
	    }
        else {
            outputHTML = '<img src="https://raw.githubusercontent.com/makaroshka11037/espmeteo/refs/heads/main/5273804146783320326.webp" alt="Если картинка не грузится - обратитесь к разработчику" width="256px" height="256px"></img>';
        }
        
        resultDiv.innerHTML = outputHTML;
    } 
    else {
        resultDiv.innerHTML = '<div style="color: orange;">Температура не найдена в данных</div>';
    }
}
</script>

    </center>
</body>
</html>
)rawliteral";