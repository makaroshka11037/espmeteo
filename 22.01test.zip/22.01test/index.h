 #pragma once

const char webpage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Метеостанция</title>
    <style type="text/css">
        .button {
            background-color: #3498db;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        body {
            background-image: url(https://img.freepik.com/premium-photo/low-angle-view-building-against-cloudy-sky_1048944-26912393.jpg);
            background-repeat: no-repeat; /* Не повторять картинку */
            background-position-y: -250px; /* Центрировать картинку */
            background-size: cover; /* Растянуть на весь экран */
            background-color: #f0f0f0; 
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #34495e;
        }

	.blok1 {
  		/* Используем rgba (красный, зеленый, синий, прозрачность от 0 до 1) */
  		background-color: rgba(255, 255, 255, 0.2); /* Белый фон на 50% прозрачный */
  
  		border: 1px solid #ccc;
  		padding: 20px;
  		width: 300px;
  		border-radius: 10px;
  
  		/* Эффект матового стекла (по желанию) */
  		backdrop-filter: blur(10px);
	}
	.temp {
		font-size: 25px;


}
	</style>
</head>
<body>
    <center>
        <div>
            <h1>METEOSTATION PANEL</h1>
	    <div class="blok1">
	    <h3>♥Дом</h3>
	    <span class="temp" id="custom_data"></p>
	    </div>


            <button class="button" id="knopka" onclick="requestCustomData()">Получить данные</button>
        </div>
        <br>
        <div>
            <h2>
                <span id="custom_data">Привет!</span>
            </h2>
        </div>

        <script>
    const button = document.getElementById('knopka');

    function requestCustomData() {
        button.innerText = 'В процессе...';

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    document.getElementById("custom_data").innerHTML = this.responseText;
                } else {
                    document.getElementById("custom_data").innerHTML = "Ошибка";
                }
                button.innerText = 'Получить данные'; // ← ТОЛЬКО ТУТ
            }
        };

        xhttp.open("GET", "/gettemp", true);
        xhttp.send();
    }
</script>
    </center>
</body>
</html>
)rawliteral";